import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { AppShell } from "@/components/shell/AppShell";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "MagHR — People, made simpler", template: "%s · MagHR" },
  description: "MagHR by MyJobMag — HR management prototype (synthetic demo data).",
  robots: { index: false, follow: false },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#152b3a",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en-NG">
      <body>
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
