import type { Metadata } from "next";
import { ComingNext } from "@/components/shell/ComingNext";

export const metadata: Metadata = { title: "Settings" };

export default function Page() {
  return (
    <ComingNext
      title="Settings"
      eyebrow="YOUR WORKSPACE, YOUR RULES"
      intro="Manage company details, access, and preferences."
      planned={[
        "Company and workspace details",
        "Currency preference (₦ default)",
        "Roles: HR Admin, Manager, Recruiter, Employee (UI only until auth is added)",
      ]}
    />
  );
}
