"use client";

// In-memory demo store. Phase 1 has no database: everything resets on refresh.
// When a backend is added, the reducer actions map naturally onto API calls.

import { createContext, useCallback, useContext, useMemo, useReducer, useSyncExternalStore, type ReactNode } from "react";
import { createDemoData } from "./demo-data";
import { recruitmentReducer, type RecruitmentAction, type RecruitmentState } from "./recruitment";

type ActionWithoutMeta = RecruitmentAction extends infer A
  ? A extends { type: "reset" }
    ? never
    : A extends unknown
      ? Omit<A, "id" | "at">
      : never
  : never;

interface StoreValue {
  state: RecruitmentState;
  /** Dispatch an action; id and timestamp are filled in automatically. Returns the generated id. */
  act: (action: ActionWithoutMeta) => string;
  resetDemo: () => void;
}

const StoreContext = createContext<StoreValue | null>(null);

let counter = 0;
export function makeId(prefix = "id"): string {
  counter += 1;
  const rand =
    typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID().slice(0, 8) : Math.random().toString(36).slice(2, 10);
  return `${prefix}-${rand}-${counter}`;
}

export function DemoStoreProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(recruitmentReducer, undefined, () => createDemoData());

  const act = useCallback((action: ActionWithoutMeta) => {
    const id = makeId(action.type.split("/")[1] ?? "x");
    dispatch({ ...action, id, at: new Date().toISOString() } as RecruitmentAction);
    return id;
  }, []);

  const resetDemo = useCallback(() => dispatch({ type: "reset", state: createDemoData() }), []);

  const value = useMemo(() => ({ state, act, resetDemo }), [state, act, resetDemo]);
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useDemoStore(): StoreValue {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useDemoStore must be used inside <DemoStoreProvider>");
  return ctx;
}

/**
 * Current time (to the minute), available only in the browser.
 * Returns null during server rendering and hydration so time-of-day text never
 * causes a hydration mismatch, then updates every minute.
 */
function subscribeToClock(onChange: () => void) {
  const t = window.setInterval(onChange, 30_000);
  return () => window.clearInterval(t);
}
const currentMinute = () => Math.floor(Date.now() / 60_000);
const serverMinute = () => null;

export function useNow(): Date | null {
  const minute = useSyncExternalStore(subscribeToClock, currentMinute, serverMinute);
  return useMemo(() => (minute === null ? null : new Date(minute * 60_000)), [minute]);
}
