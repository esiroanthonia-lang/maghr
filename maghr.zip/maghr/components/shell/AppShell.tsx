"use client";

import type { ReactNode } from "react";
import { DemoStoreProvider } from "@/lib/store";
import { ToastProvider } from "../ui/Toast";
import { DialogHost } from "./DialogHost";
import { Sidebar } from "./Sidebar";
import { Topbar } from "./Topbar";
import { UiProvider } from "./UiContext";

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <DemoStoreProvider>
      <ToastProvider>
        <UiProvider>
          <a href="#main" className="skip-link">
            Skip to content
          </a>
          <div className="app">
            <Sidebar />
            <div className="main">
              <Topbar />
              <main id="main" className="content" tabIndex={-1}>
                {children}
              </main>
              <p className="demo-banner">MAGHR · PHASE 1 FRONTEND PROTOTYPE · SYNTHETIC DEMO DATA · CHANGES RESET ON REFRESH</p>
            </div>
          </div>
          <DialogHost />
        </UiProvider>
      </ToastProvider>
    </DemoStoreProvider>
  );
}
